# Final New Conversation Prompt

Project: HARNESS Core.
Canonical directory/slug: `harness-core`.

Continue from `v2.0.0-post-active-scoped-terminal-hardening-and-final-dossier-autopilot-until-hard-stop`.

Start by reading:

- `FINAL_HANDOFF.ko.md`
- `NAME_MIGRATION.md`
- `docs/workspace/reference_baseline_policy.ko.md`
- `evidence/post-active-scoped-final-release-dossier/final_release_dossier.json`
- `evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json`

Reference baseline integrity는 `node tools/checks/workspace/check_reference_baseline_integrity.mjs`로 확인하세요.

Bare `provider-verified` is open only by release-grade provider gate evidence. Do not claim bare `adapter-checked`, `production-ready`, `stable`, `release-gated`, or bare release-gated unless the corresponding release-grade gate has executed and passed.

After any vLLM execution attempt, run `npm run check:release-grade-vllm-evidence-package` and review `evidence/release-grade-vllm-evidence-package/vllm_evidence_package_report.json` before discussing bare `adapter-checked`. For the complete path, use `npm run vllm-release-grade-evidence-gate`.

다음 중 무엇을 진행할지 물어봐 주세요.

1. vLLM execution for adapter-checked final gate
2. adapter-checked future completion
3. general release approval after adapter-checked final gate
4. 현재 final dossier/export를 최종본으로 보관
