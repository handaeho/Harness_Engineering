#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const STAGE = "v2.0.0-post-clean-export-self-contained-agent-check";
const EVIDENCE_DIR = "evidence/self-contained-agent-ready-check";

const REQUIRED_FILES = [
  "CURRENT_STATE.json",
  "CURRENT_STATE.yaml",
  "START_HERE_FOR_AGENTS.ko.md",
  "AGENT_BOOTSTRAP.ko.md",
  "AGENTS.md",
  "README.md",
  "FINAL_HANDOFF.ko.md",
  "FINAL_NEW_CONVERSATION_PROMPT.ko.md",
  "docs/how_to_apply_harness_to_agents.ko.md",
  "docs/agent_ready_self_contained_mode.ko.md",
  "tools/check_agent_ready_self_contained.mjs",
  "tools/check_clean_export_self_contained.mjs",
  "release/self_contained_agent_ready_check_scope.yaml",
  "release/self_contained_agent_ready_claim_boundary.yaml",
  "profiles/agents/codex_goal_executor.yaml",
  "profiles/agents/chatgpt_reviewer.yaml",
  "profiles/agents/local_runtime_operator.yaml",
  "profiles/agents/release_gate_reviewer.yaml",
  "evidence/current-state/current_state_index.json",
  "evidence/current-state/current_state_gate_report.json",
  "evidence/current-state/current_state_claim_boundary.json",
  "evidence/post-active-scoped-final-release-dossier/final_release_claim_state.json",
  "evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json",
  "evidence/v36-baseline/file_inventory.json",
  "evidence/v36-baseline/checksums.json"
];

const REQUIRED_SCOPED_ALLOWED_CLAIMS = [
  "provider-diverse",
  "local-model-verified",
  "post-export-active-provider-lanes-verified",
  "post-export-active-adapters-checked",
  "post-export-active-scoped-production-ready",
  "post-export-active-scoped-stable",
  "post-rc-openai-only-stable",
  "post-rc-openai-only-production-ready",
  "production-monitored",
  "telemetry-connected",
  "containment-verified",
  "rc1-openai-scope-release-gated"
];

const REQUIRED_WEAK_CLAIMS = [
  "self-contained-agent-ready-check-recorded",
  "self-contained-clean-export-checked",
  "current-state-json-recorded"
];

const BLOCKED_STRONG_CLAIMS = [
  "provider-verified",
  "adapter-checked",
  "production-ready",
  "stable",
  "release-gated"
];

const EXECUTION_FLAGS_MUST_BE_FALSE = [
  "openai_model_api_call",
  "openai_provider_rerun",
  "new_local_model_execution",
  "local_model_generation",
  "telemetry_sink_write",
  "redteam_rerun",
  "adapter_conformance_rerun",
  "npm_install_or_ci",
  "release_gate_rerun",
  "raw_request_storage",
  "raw_response_storage",
  "secret_storage"
];

function detectRoot(start) {
  if (fs.existsSync(path.join(start, "CURRENT_STATE.json"))) return start;
  const nested = path.join(start, "prompt-stack-v2");
  if (fs.existsSync(path.join(nested, "CURRENT_STATE.json"))) return nested;
  return start;
}

const root = detectRoot(process.cwd());

function p(relPath) {
  return path.join(root, ...relPath.split("/"));
}

function writeJson(relPath, data) {
  const file = p(relPath);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
}

function readText(relPath) {
  return fs.readFileSync(p(relPath), "utf8").replace(/^\uFEFF/, "");
}

function readJson(relPath) {
  try {
    return JSON.parse(readText(relPath));
  } catch {
    return null;
  }
}

function addCheck(checks, name, pass, detail = {}) {
  checks.push({ name, status: pass ? "pass" : "fail", detail });
}

function hasPath(relPath) {
  return fs.existsSync(p(relPath));
}

function arrayIncludesAll(values, required) {
  return Array.isArray(values) && required.every((item) => values.includes(item));
}

function collectFilePaths(files) {
  if (!files) return [];
  if (Array.isArray(files)) {
    return files.flatMap((item) => {
      if (typeof item === "string") return [item];
      if (!item || typeof item !== "object") return [];
      return [item.path, item.file, item.relative_path, item.relativePath].filter((value) => typeof value === "string");
    });
  }
  if (typeof files === "object") {
    return Object.entries(files).flatMap(([key, value]) => {
      const paths = [];
      if (key && key.includes("/")) paths.push(key);
      if (typeof value === "string") paths.push(value);
      if (value && typeof value === "object") {
        paths.push(value.path, value.file, value.relative_path, value.relativePath);
      }
      return paths.filter((item) => typeof item === "string");
    });
  }
  return [];
}

function snapshotExclusionBasenames(...docs) {
  const names = new Set();
  for (const doc of docs) {
    const policy = doc?.snapshot_exclusion_policy || doc?.refresh_metadata?.snapshot_exclusion_policy || {};
    for (const name of policy.excluded_basenames || []) names.add(name);
  }
  return [...names].sort();
}

function findExternalImports(relPath) {
  if (!hasPath(relPath)) return [{ specifier: "missing-file", reason: "file missing" }];
  const text = readText(relPath);
  const matches = [];
  const patterns = [
    /import\s+(?:[^"'()]+?\s+from\s+)?["']([^"']+)["']/g,
    /import\s*\(\s*["']([^"']+)["']\s*\)/g,
    /require\s*\(\s*["']([^"']+)["']\s*\)/g
  ];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      const specifier = match[1];
      if (!specifier.startsWith("node:")) {
        matches.push({ specifier, reason: "not a node: built-in import" });
      }
    }
  }
  return matches;
}

function walkForBasename(dir, basename, found = []) {
  if (!fs.existsSync(dir)) return found;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, entry.name);
    const rel = path.relative(root, abs).split(path.sep).join("/");
    if (["node_modules", "dist", ".git", "exports"].some((item) => rel === item || rel.startsWith(`${item}/`))) continue;
    if (entry.name === basename) found.push(rel);
    if (entry.isDirectory()) walkForBasename(abs, basename, found);
  }
  return found;
}

function extractClaimFlagsFromCurrentState(currentState) {
  const allowed = currentState?.allowed_claims || [];
  return {
    provider_verified_allowed: allowed.includes("provider-verified"),
    adapter_checked_allowed: allowed.includes("adapter-checked"),
    production_ready_allowed: allowed.includes("production-ready"),
    stable_allowed: allowed.includes("stable"),
    release_gated_allowed: allowed.includes("release-gated")
  };
}

const checks = [];
for (const relPath of REQUIRED_FILES) {
  addCheck(checks, `${relPath} exists`, hasPath(relPath), { path: relPath });
}

const currentState = readJson("CURRENT_STATE.json");
const currentStateYamlExists = hasPath("CURRENT_STATE.yaml");
const currentStateJsonValid = currentState !== null;
const claimFlags = extractClaimFlagsFromCurrentState(currentState);

addCheck(checks, "CURRENT_STATE.json is valid JSON", currentStateJsonValid);
addCheck(checks, "CURRENT_STATE.yaml exists", currentStateYamlExists);
addCheck(checks, "agent_ready_export path recorded", currentState?.agent_ready_export?.path === "exports/prompt-stack-v2-final-agent-ready.zip", {
  agent_ready_export: currentState?.agent_ready_export || null
});
addCheck(checks, "agent_ready_export checksum remains external", currentState?.agent_ready_export?.checksum_report_path === "evidence/clean-artifact-prune/agent_ready_clean_export_report.json"
  && currentState?.agent_ready_export?.sha256 === undefined, {
  agent_ready_export: currentState?.agent_ready_export || null
});
addCheck(checks, "latest_dossier_export separated", currentState?.latest_export === undefined
  && currentState?.latest_dossier_export?.path === "exports/v2.0.0-rc.1-postrc-final-dossier-export.zip", {
  latest_export: currentState?.latest_export || null,
  latest_dossier_export: currentState?.latest_dossier_export || null
});
addCheck(checks, "operation mode records root workspace primary", currentState?.operation_mode?.primary === "root_workspace"
  && currentState?.operation_mode?.secondary === "agent_ready_export", {
  operation_mode: currentState?.operation_mode || null
});
addCheck(checks, "root workspace mode records first command", currentState?.root_workspace?.purpose === "primary_operating_mode"
  && currentState?.root_workspace?.entrypoint === "START_HERE_FOR_AGENTS.ko.md"
  && currentState?.root_workspace?.current_state_json === "CURRENT_STATE.json"
  && currentState?.root_workspace?.current_state_yaml === "CURRENT_STATE.yaml"
  && currentState?.root_workspace?.bootstrap === "AGENT_BOOTSTRAP.ko.md"
  && currentState?.root_workspace?.first_command === "node tools/check_agent_ready_self_contained.mjs", {
  root_workspace: currentState?.root_workspace || null
});
addCheck(checks, "agent-ready export mode records transfer purpose", currentState?.agent_ready_export?.purpose === "transfer_or_archive_mode"
  && currentState?.agent_ready_export?.path === "exports/prompt-stack-v2-final-agent-ready.zip"
  && currentState?.agent_ready_export?.checksum_report_path === "evidence/clean-artifact-prune/agent_ready_clean_export_report.json", {
  agent_ready_export: currentState?.agent_ready_export || null
});
addCheck(checks, "required scoped claims recorded", arrayIncludesAll(currentState?.allowed_claims, REQUIRED_SCOPED_ALLOWED_CLAIMS), {
  required: REQUIRED_SCOPED_ALLOWED_CLAIMS,
  allowed_claims: currentState?.allowed_claims || null
});
addCheck(checks, "weak self-contained claims recordable", arrayIncludesAll(currentState?.self_contained_agent_ready_check?.weak_claims_recordable, REQUIRED_WEAK_CLAIMS), {
  required: REQUIRED_WEAK_CLAIMS,
  weak_claims_recordable: currentState?.self_contained_agent_ready_check?.weak_claims_recordable || null
});
addCheck(checks, "strong bare claims remain blocked", arrayIncludesAll(currentState?.blocked_claims, [
  ...BLOCKED_STRONG_CLAIMS,
  "bare release-gated"
]), {
  blocked_claims: currentState?.blocked_claims || null
});
addCheck(checks, "strong bare claims not allowed", Object.values(claimFlags).every((value) => value === false), claimFlags);
addCheck(checks, "forbidden execution flags remain false", EXECUTION_FLAGS_MUST_BE_FALSE.every((flag) => currentState?.execution_boundary?.[flag] === false), {
  execution_boundary: currentState?.execution_boundary || null
});
addCheck(checks, "self-contained checker policy recorded", currentState?.self_contained_agent_ready_check?.requires_node_modules === false
  && currentState?.self_contained_agent_ready_check?.requires_npm_install === false
  && currentState?.self_contained_agent_ready_check?.requires_sibling_prompt_stack_v36 === false
  && currentState?.self_contained_agent_ready_check?.v36_source_check_policy === "snapshot_files_only", {
  self_contained_agent_ready_check: currentState?.self_contained_agent_ready_check || null
});

const importLeaks = [
  ...findExternalImports("tools/check_agent_ready_self_contained.mjs").map((item) => ({ file: "tools/check_agent_ready_self_contained.mjs", ...item })),
  ...findExternalImports("tools/check_clean_export_self_contained.mjs").map((item) => ({ file: "tools/check_clean_export_self_contained.mjs", ...item }))
];
addCheck(checks, "self-contained checkers use only Node built-in imports", importLeaks.length === 0, { external_imports: importLeaks });

const inventory = readJson("evidence/v36-baseline/file_inventory.json");
const checksums = readJson("evidence/v36-baseline/checksums.json");
const inventoryPaths = collectFilePaths(inventory?.files);
const checksumPaths = collectFilePaths(checksums?.files);
const snapshotPaths = [...inventoryPaths, ...checksumPaths];
const dsStoreSnapshotPaths = snapshotPaths.filter((item) => path.basename(item) === ".DS_Store" || item.includes("/.DS_Store"));
const excludedBasenames = snapshotExclusionBasenames(inventory, checksums);

addCheck(checks, "v36 baseline snapshot files are present", inventory !== null && checksums !== null, {
  file_inventory_present: inventory !== null,
  checksums_present: checksums !== null
});
addCheck(checks, "v36 baseline snapshot paths recorded", inventoryPaths.length > 0 && checksumPaths.length > 0, {
  inventory_paths_count: inventoryPaths.length,
  checksum_paths_count: checksumPaths.length
});
addCheck(checks, "v36 baseline snapshot excludes .DS_Store paths", dsStoreSnapshotPaths.length === 0, {
  ds_store_snapshot_paths: dsStoreSnapshotPaths
});
addCheck(checks, "v36 baseline .DS_Store exclusion policy recorded", excludedBasenames.includes(".DS_Store"), {
  excluded_basenames: excludedBasenames
});

const localPackageState = {
  node_modules_present: fs.existsSync(p("node_modules")),
  dist_present: fs.existsSync(p("dist")),
  git_metadata_present_in_package_root: fs.existsSync(p(".git")),
  exports_present: fs.existsSync(p("exports")),
  archive_legacy_handoffs_present: fs.existsSync(p("archive/legacy-handoffs")),
  ds_store_paths: walkForBasename(root, ".DS_Store")
};
const forbiddenPathsAbsent = !localPackageState.node_modules_present
  && !localPackageState.dist_present
  && !localPackageState.git_metadata_present_in_package_root
  && !localPackageState.archive_legacy_handoffs_present
  && localPackageState.ds_store_paths.length === 0;
const cleanExportContextDetected = !localPackageState.exports_present
  && !localPackageState.node_modules_present
  && !localPackageState.dist_present
  && !localPackageState.archive_legacy_handoffs_present;
addCheck(checks, "forbidden paths absent in clean export context", cleanExportContextDetected ? forbiddenPathsAbsent : true, {
  clean_export_context_detected: cleanExportContextDetected,
  forbidden_paths_absent: forbiddenPathsAbsent,
  local_package_state: localPackageState,
  note: cleanExportContextDetected ? "Clean export context detected." : "Source worktree context detected; zip-level forbidden path checks are enforced by check_clean_export_self_contained.mjs."
});

const currentStateCheck = {
  status: checks.filter((check) => check.name.startsWith("CURRENT_STATE")
    || check.name.includes("agent_ready_export")
    || check.name.includes("latest_dossier_export")
    || check.name.includes("operation mode")
    || check.name.includes("root workspace")
    || check.name.includes("agent-ready export mode")).every((check) => check.status === "pass") ? "pass" : "fail",
  stage: STAGE,
  current_state_json_exists: hasPath("CURRENT_STATE.json"),
  current_state_yaml_exists: currentStateYamlExists,
  current_state_json_valid: currentStateJsonValid,
  operation_mode: currentState?.operation_mode || null,
  root_workspace: currentState?.root_workspace || null,
  agent_ready_export: currentState?.agent_ready_export || null,
  latest_dossier_export: currentState?.latest_dossier_export || null
};

const v36BaselineSnapshotCheck = {
  status: inventory !== null && checksums !== null && inventoryPaths.length > 0 && checksumPaths.length > 0 && dsStoreSnapshotPaths.length === 0 && excludedBasenames.includes(".DS_Store") ? "pass" : "fail",
  stage: STAGE,
  policy: "snapshot_files_only",
  requires_sibling_prompt_stack_v36_source: false,
  inventory_paths_count: inventoryPaths.length,
  checksum_paths_count: checksumPaths.length,
  ds_store_snapshot_paths: dsStoreSnapshotPaths,
  excluded_basenames: excludedBasenames
};

const claimBoundaryCheck = {
  status: arrayIncludesAll(currentState?.allowed_claims, REQUIRED_SCOPED_ALLOWED_CLAIMS)
    && arrayIncludesAll(currentState?.self_contained_agent_ready_check?.weak_claims_recordable, REQUIRED_WEAK_CLAIMS)
    && arrayIncludesAll(currentState?.blocked_claims, [...BLOCKED_STRONG_CLAIMS, "bare release-gated"])
    && Object.values(claimFlags).every((value) => value === false)
    ? "pass"
    : "fail",
  stage: STAGE,
  weak_claims_recorded: REQUIRED_WEAK_CLAIMS,
  provider_verified_allowed: claimFlags.provider_verified_allowed,
  adapter_checked_allowed: claimFlags.adapter_checked_allowed,
  production_ready_allowed: claimFlags.production_ready_allowed,
  stable_allowed: claimFlags.stable_allowed,
  release_gated_allowed: claimFlags.release_gated_allowed,
  blocked_claims: currentState?.blocked_claims || null
};

const failures = checks.filter((check) => check.status !== "pass");
const unresolvedItems = failures.map((failure) => ({
  id: failure.name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, ""),
  status: "blocked",
  reason: failure.name,
  detail: failure.detail
}));

const report = {
  status: failures.length === 0 ? "pass" : "fail",
  stage: STAGE,
  generated_at: new Date().toISOString(),
  checker: "check_agent_ready_self_contained.mjs",
  weak_claims_recorded: REQUIRED_WEAK_CLAIMS,
  dependency_free: importLeaks.length === 0,
  requires_node_modules: false,
  requires_npm_install: false,
  requires_prompt_stack_v36_source: false,
  v36_source_check_policy: "snapshot_files_only",
  current_state_json_exists: hasPath("CURRENT_STATE.json"),
  current_state_yaml_exists: currentStateYamlExists,
  operation_mode_primary: currentState?.operation_mode?.primary || null,
  operation_mode_secondary: currentState?.operation_mode?.secondary || null,
  root_workspace_first_command: currentState?.root_workspace?.first_command || null,
  claim_boundary_passed: claimBoundaryCheck.status === "pass",
  v36_snapshot_check_passed: v36BaselineSnapshotCheck.status === "pass",
  forbidden_paths_absent: forbiddenPathsAbsent,
  clean_export_context_detected: cleanExportContextDetected,
  forbidden_package_roots_required: false,
  local_package_state: localPackageState,
  provider_verified_allowed: claimFlags.provider_verified_allowed,
  adapter_checked_allowed: claimFlags.adapter_checked_allowed,
  production_ready_allowed: claimFlags.production_ready_allowed,
  stable_allowed: claimFlags.stable_allowed,
  release_gated_allowed: claimFlags.release_gated_allowed,
  checks,
  failures,
  unresolved_items_count: unresolvedItems.length,
  unresolved_items: unresolvedItems
};

const gateReport = {
  status: report.status,
  stage: STAGE,
  generated_at: report.generated_at,
  self_contained_agent_ready_check_recorded: report.status === "pass",
  self_contained_clean_export_checked: false,
  current_state_json_recorded: report.current_state_json_exists && currentStateJsonValid,
  dependency_free: report.dependency_free,
  provider_verified_allowed: false,
  adapter_checked_allowed: false,
  production_ready_allowed: false,
  stable_allowed: false,
  release_gated_allowed: false,
  unresolved_items_count: unresolvedItems.length
};

writeJson(`${EVIDENCE_DIR}/self_contained_current_state_check.json`, currentStateCheck);
writeJson(`${EVIDENCE_DIR}/self_contained_v36_baseline_snapshot_check.json`, v36BaselineSnapshotCheck);
writeJson(`${EVIDENCE_DIR}/self_contained_claim_boundary_check.json`, claimBoundaryCheck);
writeJson(`${EVIDENCE_DIR}/self_contained_agent_ready_check_report.json`, report);
writeJson(`${EVIDENCE_DIR}/self_contained_gate_report.json`, gateReport);
writeJson(`${EVIDENCE_DIR}/unresolved_items.json`, {
  status: report.status === "pass" ? "pass" : "blocked",
  stage: STAGE,
  generated_at: report.generated_at,
  unresolved_items_count: unresolvedItems.length,
  unresolved_items: unresolvedItems
});

const cleanExportCheckPath = `${EVIDENCE_DIR}/self_contained_clean_export_check.json`;
if (!hasPath(cleanExportCheckPath)) {
  writeJson(cleanExportCheckPath, {
    status: "not_run",
    stage: STAGE,
    generated_at: report.generated_at,
    note: "Run node tools/check_clean_export_self_contained.mjs to inspect the clean export archive."
  });
}

console.log(JSON.stringify(report, null, 2));
process.exit(report.status === "pass" ? 0 : 1);
