#!/usr/bin/env node
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { parse as parseYaml } from "yaml";

const STAGE = "v2.0.0-post-clean-export-agent-ready-usability-polish";
const REQUIRED_PROFILES = [
  "profiles/agents/codex_goal_executor.yaml",
  "profiles/agents/chatgpt_reviewer.yaml",
  "profiles/agents/local_runtime_operator.yaml",
  "profiles/agents/release_gate_reviewer.yaml"
];
const REQUIRED_BLOCKED = [
  "provider-verified",
  "adapter-checked",
  "production-ready",
  "stable",
  "release-gated",
  "bare release-gated"
];
const EXPECTED_DIRTY_BASELINE_PATHS = new Set([
  "prompt-stack-v2/evidence/v36-baseline/checksums.json",
  "prompt-stack-v2/evidence/v36-baseline/file_inventory.json"
]);

const repoRoot = process.cwd();
const root = path.basename(repoRoot) === "prompt-stack-v2"
  ? repoRoot
  : path.resolve(repoRoot, "prompt-stack-v2");
const gitRoot = path.resolve(root, "..");

function p(...parts) {
  return path.join(root, ...parts);
}

function readText(file) {
  return fs.readFileSync(file, "utf8");
}

function readJson(file) {
  return JSON.parse(readText(file));
}

function readYaml(file) {
  return parseYaml(readText(file));
}

function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
}

function writeText(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, data);
}

function sha256File(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function sameArray(a, b) {
  return Array.isArray(a)
    && Array.isArray(b)
    && a.length === b.length
    && a.every((item, index) => item === b[index]);
}

function addCheck(checks, name, pass, detail = {}) {
  checks.push({ name, status: pass ? "pass" : "fail", detail });
}

function gitStatusProtected() {
  const result = spawnSync("git", [
    "-C",
    gitRoot,
    "status",
    "--short",
    "--",
    "prompt-stack/v36",
    "dist",
    "prompt-stack-v2/dist",
    "prompt-stack-v2/evidence/v36-baseline"
  ], { encoding: "utf8" });
  const paths = result.stdout
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => line.replace(/^[ MADRCU?!]{1,2}\s+/, ""));
  const v36Dirty = paths.filter((item) => item.startsWith("prompt-stack/v36/"));
  const distDirty = paths.filter((item) => item === "dist" || item.startsWith("dist/") || item.startsWith("prompt-stack-v2/dist/"));
  const baselineDirty = paths.filter((item) => item.startsWith("prompt-stack-v2/evidence/v36-baseline/"));
  const unexpectedBaselineDirty = baselineDirty.filter((item) => !EXPECTED_DIRTY_BASELINE_PATHS.has(item));
  return {
    exit_code: result.status,
    stdout: result.stdout.trim(),
    stderr: result.stderr.trim(),
    observed_dirty_paths: paths,
    v36_dirty_paths: v36Dirty,
    dist_dirty_paths: distDirty,
    evidence_v36_baseline_dirty_paths: baselineDirty,
    unexpected_evidence_v36_baseline_dirty_paths: unexpectedBaselineDirty,
    v36_modified: v36Dirty.length > 0,
    dist_modified: distDirty.length > 0,
    evidence_v36_baseline_refreshed: unexpectedBaselineDirty.length > 0
  };
}

const checks = [];
const requiredFiles = [
  "CURRENT_STATE.yaml",
  "START_HERE_FOR_AGENTS.ko.md",
  "AGENT_BOOTSTRAP.ko.md",
  "docs/how_to_apply_harness_to_agents.ko.md",
  "AGENTS.md",
  "README.md",
  "stack.yaml",
  "docs/session_handoff_latest.md",
  "adapters/provider_capability_matrix.yaml",
  "evidence/post-active-scoped-final-release-dossier/final_release_claim_state.json",
  "evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json",
  ...REQUIRED_PROFILES
];

for (const file of requiredFiles) {
  addCheck(checks, `${file} exists`, fs.existsSync(p(file)), { file });
}

const currentState = fs.existsSync(p("CURRENT_STATE.yaml")) ? readYaml(p("CURRENT_STATE.yaml")) : null;
const finalClaimState = currentState?.final_dossier?.claim_state_path && fs.existsSync(p(currentState.final_dossier.claim_state_path))
  ? readJson(p(currentState.final_dossier.claim_state_path))
  : null;
const finalExportReport = currentState?.final_dossier?.export_report_path && fs.existsSync(p(currentState.final_dossier.export_report_path))
  ? readJson(p(currentState.final_dossier.export_report_path))
  : null;
const stack = fs.existsSync(p("stack.yaml")) ? readYaml(p("stack.yaml")) : null;
const providerMatrix = fs.existsSync(p("adapters/provider_capability_matrix.yaml"))
  ? readYaml(p("adapters/provider_capability_matrix.yaml"))
  : null;

const agentsText = fs.existsSync(p("AGENTS.md")) ? readText(p("AGENTS.md")) : "";
const readmeText = fs.existsSync(p("README.md")) ? readText(p("README.md")) : "";
const startHereText = fs.existsSync(p("START_HERE_FOR_AGENTS.ko.md")) ? readText(p("START_HERE_FOR_AGENTS.ko.md")) : "";
const handoffText = fs.existsSync(p("docs/session_handoff_latest.md")) ? readText(p("docs/session_handoff_latest.md")) : "";
const bootstrapText = fs.existsSync(p("AGENT_BOOTSTRAP.ko.md")) ? readText(p("AGENT_BOOTSTRAP.ko.md")) : "";
const howToText = fs.existsSync(p("docs/how_to_apply_harness_to_agents.ko.md"))
  ? readText(p("docs/how_to_apply_harness_to_agents.ko.md"))
  : "";

addCheck(checks, "AGENTS.md references CURRENT_STATE.yaml", agentsText.includes("CURRENT_STATE.yaml"));
addCheck(checks, "README reflects split export state", readmeText.includes("v2.0.0-rc.1-postrc-final-dossier")
  && readmeText.includes(currentState?.agent_ready_export?.path || "__missing__")
  && readmeText.includes(currentState?.latest_dossier_export?.path || "__missing__"));
addCheck(checks, "START_HERE names agent-ready clean export", startHereText.includes("exports/prompt-stack-v2-final-agent-ready.zip")
  && startHereText.includes("latest_dossier_export"));
addCheck(checks, "stack.yaml status/version not stale", stack?.version === "v2.0.0"
  && stack?.status === "v2.0.0-rc.1-postrc-final-dossier");
addCheck(checks, "docs/session_handoff_latest.md points to final handoff or current state", handoffText.includes("CURRENT_STATE.yaml")
  && handoffText.includes("FINAL_HANDOFF.ko.md"));
addCheck(checks, "bootstrap required phrase present", bootstrapText.includes("이 하네스는 프롬프트 묶음이 아니라, 에이전트가 claim을 과장하지 않고 evidence/gate 기반으로 작업하도록 만드는 운영 레이어입니다."));
addCheck(checks, "bootstrap names agent-ready clean export", bootstrapText.includes("새 에이전트에게는 `prompt-stack-v2-final-agent-ready.zip`을 전달한다."));
addCheck(checks, "how-to document explains agent application layer", howToText.includes("Agent application layer")
  || howToText.includes("agent application layer"));

if (currentState && finalClaimState) {
  addCheck(checks, "allowed claims match final_release_claim_state", sameArray(currentState.allowed_claims, finalClaimState.allowed_claims), {
    current_state_allowed_claims: currentState.allowed_claims,
    final_claim_state_allowed_claims: finalClaimState.allowed_claims
  });
  addCheck(checks, "blocked claims match final_release_claim_state", sameArray(currentState.blocked_claims, finalClaimState.blocked_claims), {
    current_state_blocked_claims: currentState.blocked_claims,
    final_claim_state_blocked_claims: finalClaimState.blocked_claims
  });
  for (const claim of REQUIRED_BLOCKED) {
    addCheck(checks, `${claim} remains blocked`, finalClaimState.blocked_claims?.includes(claim) === true);
  }
  addCheck(checks, "provider-verified allowed flag remains false", finalClaimState.provider_verified_allowed === false);
  addCheck(checks, "adapter-checked allowed flag remains false", finalClaimState.adapter_checked_allowed === false);
  addCheck(checks, "production-ready allowed flag remains false", finalClaimState.production_ready_allowed === false);
  addCheck(checks, "stable allowed flag remains false", finalClaimState.stable_allowed === false);
  addCheck(checks, "release-gated allowed flag remains false", finalClaimState.release_gated_allowed === false);
}

if (currentState) {
  addCheck(checks, "legacy latest_export field absent", currentState.latest_export === undefined, {
    latest_export: currentState.latest_export || null
  });
  const agentReadyExportPath = currentState.agent_ready_export?.path ? p(currentState.agent_ready_export.path) : null;
  const agentReadyExportExists = agentReadyExportPath ? fs.existsSync(agentReadyExportPath) : false;
  const observedAgentReadySha = agentReadyExportExists ? sha256File(agentReadyExportPath) : null;
  addCheck(checks, "agent_ready_export path exists", agentReadyExportExists, { path: currentState.agent_ready_export?.path || null });
  addCheck(checks, "agent_ready_export is clean export", currentState.agent_ready_export?.path === "exports/prompt-stack-v2-final-agent-ready.zip", {
    path: currentState.agent_ready_export?.path || null
  });
  addCheck(checks, "agent_ready_export checksum is external report", currentState.agent_ready_export?.checksum_report_path === "evidence/clean-artifact-prune/agent_ready_clean_export_report.json"
    && currentState.agent_ready_export?.sha256 === undefined, {
    checksum_report_path: currentState.agent_ready_export?.checksum_report_path || null,
    embedded_sha256: currentState.agent_ready_export?.sha256 || null
  });
  const dossierExportPath = currentState.latest_dossier_export?.path ? p(currentState.latest_dossier_export.path) : null;
  const dossierExportExists = dossierExportPath ? fs.existsSync(dossierExportPath) : false;
  const observedDossierSha = dossierExportExists ? sha256File(dossierExportPath) : null;
  addCheck(checks, "latest_dossier_export path exists", dossierExportExists, { path: currentState.latest_dossier_export?.path || null });
  addCheck(checks, "latest_dossier_export sha256 matches", observedDossierSha === currentState.latest_dossier_export?.sha256, {
    expected: currentState.latest_dossier_export?.sha256 || null,
    observed: observedDossierSha
  });
  addCheck(checks, "latest_dossier_export is dossier export", currentState.latest_dossier_export?.path === "exports/v2.0.0-rc.1-postrc-final-dossier-export.zip", {
    path: currentState.latest_dossier_export?.path || null
  });
  addCheck(checks, "OpenAI model API call false", currentState.execution_boundary?.openai_model_api_call === false
    && finalClaimState?.openai_model_api_call === false
    && finalExportReport?.openai_model_api_call === false);
  addCheck(checks, "new local model execution false", currentState.execution_boundary?.new_local_model_execution === false
    && finalClaimState?.new_local_model_execution === false
    && finalExportReport?.new_local_model_execution === false);
  addCheck(checks, "telemetry sink write false", currentState.execution_boundary?.telemetry_sink_write === false
    && finalClaimState?.telemetry_sink_write === false
    && finalExportReport?.telemetry_sink_write === false);
}

if (providerMatrix) {
  addCheck(checks, "provider capability matrix status reflects final dossier", providerMatrix.status === "active_scoped_final_dossier_recorded");
  addCheck(checks, "Ollama local lane no longer blocked by missing endpoint", providerMatrix.providers?.ollama?.local_no_tool_canary !== "blocked_by_missing_local_endpoint", {
    ollama_local_no_tool_canary: providerMatrix.providers?.ollama?.local_no_tool_canary
  });
  addCheck(checks, "provider matrix does not enable bare verified flags", Object.values(providerMatrix.providers || {}).every((provider) => provider.verified === false));
}

const protectedStatus = gitStatusProtected();
addCheck(checks, "v36 modified false", protectedStatus.v36_modified === false, protectedStatus);
addCheck(checks, "dist modified false", protectedStatus.dist_modified === false, protectedStatus);
addCheck(checks, "evidence/v36-baseline refreshed false", protectedStatus.evidence_v36_baseline_refreshed === false, protectedStatus);

const failures = checks.filter((check) => check.status !== "pass");
const report = {
  status: failures.length === 0 ? "pass" : "fail",
  stage: STAGE,
  generated_at: new Date().toISOString(),
  checks,
  failures,
  unresolved_items_count: failures.length,
  protected_path_status: protectedStatus,
  agent_ready_export: currentState?.agent_ready_export || null,
  latest_dossier_export: currentState?.latest_dossier_export || null,
  weak_claims_recorded: [
    "post-final-dossier-agent-application-layer-recorded",
    "post-final-dossier-current-state-aligned"
  ],
  new_local_model_execution: false,
  openai_model_api_call: false,
  openai_provider_rerun: false,
  telemetry_sink_write: false,
  npm_install_or_ci: false,
  v36_modified: protectedStatus.v36_modified,
  dist_modified: protectedStatus.dist_modified,
  evidence_v36_baseline_refreshed: protectedStatus.evidence_v36_baseline_refreshed,
  provider_verified_allowed: false,
  adapter_checked_allowed: false,
  production_ready_allowed: false,
  stable_allowed: false,
  release_gated_allowed: false
};

const md = `# Current State Alignment Gate

Status: ${report.status}

- Stage: ${STAGE}
- Checks: ${checks.length}
- Failures: ${failures.length}
- Agent-ready export: ${currentState?.agent_ready_export?.path || "missing"}
- Latest dossier export: ${currentState?.latest_dossier_export?.path || "missing"}
- New local model execution: false
- OpenAI model API call: false
- Telemetry sink write: false
- v36 modified: ${protectedStatus.v36_modified}
- dist modified: ${protectedStatus.dist_modified}
- evidence/v36-baseline refreshed: ${protectedStatus.evidence_v36_baseline_refreshed}
`;

writeJson(p("evidence/current-state/current_state_gate_report.json"), report);
writeJson(p("evidence/current-state/current_state_alignment_report.json"), report);
writeJson(p("evidence/current-state/unresolved_items.json"), {
  status: report.status,
  stage: STAGE,
  unresolved_items_count: failures.length,
  unresolved_items: failures
});
writeJson(p("evals/reports/current_state_alignment_report.json"), report);
writeText(p("evals/reports/current_state_alignment_report.md"), md);

console.log(JSON.stringify(report, null, 2));
process.exit(report.status === "pass" ? 0 : 1);
