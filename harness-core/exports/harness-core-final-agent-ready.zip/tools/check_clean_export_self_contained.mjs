#!/usr/bin/env node
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

const STAGE = "v2.0.0-post-clean-export-internal-sha-report-scrub";
const EVIDENCE_DIR = "evidence/self-contained-agent-ready-check";
const CLEAN_EXPORT_PATH = "exports/prompt-stack-v2-final-agent-ready.zip";
const OLD_CLEAN_EXPORT_SHA_VALUES = [
  [
    "88748e3f",
    "3a61f06d",
    "4b7c170d",
    "798db524",
    "95c5aa1e",
    "4f93e329",
    "5960eb59",
    "b0336f35"
  ].join(""),
  [
    "ffd62ac5",
    "9971f262",
    "7d7ecd9f",
    "04c18747",
    "903ffdba",
    "606bc5a9",
    "a8a1744b",
    "84c4554a"
  ].join("")
];

const INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES = [
  "evidence/self-contained-agent-ready-check/self_contained_clean_export_check.json",
  "evidence/self-contained-agent-ready-check/self_contained_gate_report.json"
];

const REQUIRED_ENTRIES = [
  "CURRENT_STATE.json",
  "CURRENT_STATE.yaml",
  "START_HERE_FOR_AGENTS.ko.md",
  "AGENT_BOOTSTRAP.ko.md",
  "AGENTS.md",
  "README.md",
  "docs/agent_ready_self_contained_mode.ko.md",
  "tools/check_agent_ready_self_contained.mjs",
  "tools/check_clean_export_self_contained.mjs",
  "release/self_contained_agent_ready_check_scope.yaml",
  "release/self_contained_agent_ready_claim_boundary.yaml",
  "profiles/agents/codex_goal_executor.yaml",
  "profiles/agents/chatgpt_reviewer.yaml",
  "profiles/agents/local_runtime_operator.yaml",
  "profiles/agents/release_gate_reviewer.yaml",
  "evidence/current-state/current_state_index.json",
  "evidence/current-state/current_state_gate_report.json",
  "evidence/current-state/current_state_claim_boundary.json",
  "evidence/v36-baseline/file_inventory.json",
  "evidence/v36-baseline/checksums.json"
];

function detectRoot(start) {
  if (fs.existsSync(path.join(start, "CURRENT_STATE.json"))) return start;
  const nested = path.join(start, "prompt-stack-v2");
  if (fs.existsSync(path.join(nested, "CURRENT_STATE.json"))) return nested;
  return start;
}

const root = detectRoot(process.cwd());

function p(relPath) {
  return path.join(root, ...relPath.split("/"));
}

function writeJson(relPath, data) {
  const file = p(relPath);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
}

function sha256File(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function addCheck(checks, name, pass, detail = {}) {
  checks.push({ name, status: pass ? "pass" : "fail", detail });
}

function zipEntries(zipPath) {
  const zipinfo = spawnSync("zipinfo", ["-1", zipPath], {
    encoding: "utf8",
    maxBuffer: 80 * 1024 * 1024
  });
  if (zipinfo.status === 0) {
    return {
      exit_code: 0,
      stderr: zipinfo.stderr.trim(),
      entries: zipinfo.stdout.split(/\r?\n/).filter(Boolean).sort(),
      method: "zipinfo -1"
    };
  }

  const unzip = spawnSync("unzip", ["-Z1", zipPath], {
    encoding: "utf8",
    maxBuffer: 80 * 1024 * 1024
  });
  return {
    exit_code: unzip.status,
    stderr: unzip.stderr.trim() || zipinfo.stderr.trim(),
    entries: unzip.status === 0 ? unzip.stdout.split(/\r?\n/).filter(Boolean).sort() : [],
    method: unzip.status === 0 ? "unzip -Z1" : "zipinfo -1"
  };
}

function forbiddenEntries(entries) {
  return {
    node_modules: entries.filter((entry) => entry === "node_modules/" || entry.startsWith("node_modules/") || entry.includes("/node_modules/")),
    dist: entries.filter((entry) => entry === "dist/" || entry.startsWith("dist/") || entry.includes("/dist/")),
    git_metadata: entries.filter((entry) => entry === ".git/" || entry.startsWith(".git/") || entry.includes("/.git/")),
    ds_store: entries.filter((entry) => path.basename(entry) === ".DS_Store"),
    old_exports: entries.filter((entry) => entry.startsWith("exports/") && entry.endsWith(".zip")),
    archive_legacy_handoffs: entries.filter((entry) => entry === "archive/legacy-handoffs/" || entry.startsWith("archive/legacy-handoffs/")),
    nested_prompt_stack_v2: entries.filter((entry) => entry === "prompt-stack-v2/" || entry.startsWith("prompt-stack-v2/") || entry.includes("/prompt-stack-v2/")),
    internal_archive_sha_reports: entries.filter((entry) => INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES.includes(entry)),
    raw_payload_path: entries.filter((entry) => /(^|\/)(raw[-_])?(request|response)[-_]?payload/i.test(entry)
      || /(^|\/)raw[-_](request|response)/i.test(entry)),
    secret_value_path: entries.filter((entry) => /(^|\/)(secret|api[-_]?key|auth[-_]?header)[-_]?value/i.test(entry)
      || /(^|\/)\.env($|\.)/i.test(entry))
  };
}

function unzipText(zipPath, entry) {
  const result = spawnSync("unzip", ["-p", zipPath, entry], {
    encoding: "utf8",
    maxBuffer: 40 * 1024 * 1024
  });
  return result.status === 0 ? result.stdout : "";
}

function textEntries(entries) {
  return entries.filter((entry) => /\.(md|txt|yaml|yml|json|mjs|js|schema|lock)$/i.test(entry));
}

function findTextOccurrences(zipPath, entries, values) {
  const matches = [];
  const needles = values.filter(Boolean);
  for (const entry of textEntries(entries)) {
    const text = unzipText(zipPath, entry);
    for (const value of needles) {
      if (text.includes(value)) {
        matches.push({ entry, value });
      }
    }
  }
  return matches;
}

function isPolicyOrPatternEntry(entry) {
  return /(^|\/)(secret_detection_patterns|raw_storage_forbidden_patterns|telemetry_sink_credential_policy|credential_policy|redaction_policy|provider_canary_attempts)/i.test(entry);
}

function secretContentLeaks(zipPath, entries) {
  const leaks = [];
  const patterns = [
    { id: "openai_api_key_like_value", pattern: /\bsk-[A-Za-z0-9_-]{20,}\b/g },
    { id: "authorization_bearer_value", pattern: /authorization\s*:\s*bearer\s+(?!<|YOUR_|REDACTED|redacted|placeholder|example)[A-Za-z0-9._~+/=-]{12,}/gi },
    { id: "api_key_assigned_value", pattern: /\b(api[-_]?key|auth[-_]?header|secret)\b\s*[:=]\s*["']?(?!false\b|true\b|null\b|none\b|missing\b|redacted\b|REDACTED\b|placeholder\b|example\b|not_applicable\b|needs_verification\b|forbidden\b|blocked\b)[A-Za-z0-9._~+/=-]{24,}/gi }
  ];
  for (const entry of textEntries(entries)) {
    if (isPolicyOrPatternEntry(entry)) continue;
    const text = unzipText(zipPath, entry);
    for (const item of patterns) {
      item.pattern.lastIndex = 0;
      const match = item.pattern.exec(text);
      if (match) {
        leaks.push({ entry, pattern: item.id, excerpt: match[0].slice(0, 24) });
        break;
      }
    }
  }
  return leaks;
}

function parseLastJsonObject(text) {
  const trimmed = text.trim();
  if (!trimmed) return null;
  const start = trimmed.indexOf("{");
  const end = trimmed.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  try {
    return JSON.parse(trimmed.slice(start, end + 1));
  } catch {
    return null;
  }
}

function runExtractedSelfContainedCheck(zipPath) {
  const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "prompt-stack-v2-self-contained-"));
  try {
    const unzip = spawnSync("unzip", ["-q", zipPath, "-d", tempRoot], {
      encoding: "utf8",
      maxBuffer: 80 * 1024 * 1024
    });
    if (unzip.status !== 0) {
      return {
        status: "fail",
        extract_exit_code: unzip.status,
        extract_stderr: unzip.stderr.trim(),
        checker_exit_code: null,
        checker_stdout_json: null,
        checker_stderr: ""
      };
    }

    const checker = spawnSync(process.execPath, ["tools/check_agent_ready_self_contained.mjs"], {
      cwd: tempRoot,
      encoding: "utf8",
      maxBuffer: 80 * 1024 * 1024
    });
    return {
      status: checker.status === 0 ? "pass" : "fail",
      extract_exit_code: unzip.status,
      extract_stderr: unzip.stderr.trim(),
      checker_exit_code: checker.status,
      checker_stdout_json: parseLastJsonObject(checker.stdout),
      checker_stderr: checker.stderr.trim()
    };
  } finally {
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
}

const checks = [];
const exportAbs = p(CLEAN_EXPORT_PATH);
const exists = fs.existsSync(exportAbs);
const exportSha256 = exists ? sha256File(exportAbs) : null;
addCheck(checks, "clean export exists", exists, { export_path: CLEAN_EXPORT_PATH });

const zip = exists ? zipEntries(exportAbs) : {
  exit_code: 1,
  stderr: "missing clean export",
  entries: [],
  method: "not_run"
};
const entries = zip.entries;
const entrySet = new Set(entries);
addCheck(checks, "zip entries readable", zip.exit_code === 0, { method: zip.method, exit_code: zip.exit_code, stderr: zip.stderr });

const missingRequiredEntries = REQUIRED_ENTRIES.filter((entry) => !entrySet.has(entry));
for (const entry of REQUIRED_ENTRIES) {
  addCheck(checks, `${entry} included`, entrySet.has(entry), { entry });
}
const bad = forbiddenEntries(entries);
const leaks = exists && zip.exit_code === 0 ? secretContentLeaks(exportAbs, entries) : [];
const staleShaMatches = exists && zip.exit_code === 0 ? findTextOccurrences(exportAbs, entries, OLD_CLEAN_EXPORT_SHA_VALUES) : [];
const selfShaMatches = exists && zip.exit_code === 0 ? findTextOccurrences(exportAbs, entries, [exportSha256]) : [];

addCheck(checks, "internal archive SHA self-contained reports not included", bad.internal_archive_sha_reports.length === 0, {
  entries: bad.internal_archive_sha_reports
});
addCheck(checks, "node_modules not included", bad.node_modules.length === 0, { entries: bad.node_modules });
addCheck(checks, "dist not included", bad.dist.length === 0, { entries: bad.dist });
addCheck(checks, ".git not included", bad.git_metadata.length === 0, { entries: bad.git_metadata });
addCheck(checks, ".DS_Store not included", bad.ds_store.length === 0, { entries: bad.ds_store });
addCheck(checks, "archive/legacy-handoffs not included", bad.archive_legacy_handoffs.length === 0, { entries: bad.archive_legacy_handoffs });
addCheck(checks, "old exports not included", bad.old_exports.length === 0, { entries: bad.old_exports });
addCheck(checks, "nested prompt-stack-v2 residue not included", bad.nested_prompt_stack_v2.length === 0, { entries: bad.nested_prompt_stack_v2 });
addCheck(checks, "raw/secret path entries not included", bad.raw_payload_path.length === 0 && bad.secret_value_path.length === 0, { entries: bad });
addCheck(checks, "raw/secret values not included", leaks.length === 0, { leaks });
addCheck(checks, "stale clean export SHA not present", staleShaMatches.length === 0, { matches: staleShaMatches });
addCheck(checks, "clean export does not hard-code its own SHA", selfShaMatches.length === 0, { matches: selfShaMatches });

const extractedCheck = exists && zip.exit_code === 0
  ? runExtractedSelfContainedCheck(exportAbs)
  : {
    status: "fail",
    extract_exit_code: null,
    extract_stderr: "zip not available",
    checker_exit_code: null,
    checker_stdout_json: null,
    checker_stderr: ""
  };
addCheck(checks, "extracted self-contained agent check passes", extractedCheck.status === "pass", extractedCheck);
addCheck(checks, "provider-verified remains false", extractedCheck.checker_stdout_json?.provider_verified_allowed === false, {
  provider_verified_allowed: extractedCheck.checker_stdout_json?.provider_verified_allowed
});
addCheck(checks, "adapter-checked remains false", extractedCheck.checker_stdout_json?.adapter_checked_allowed === false, {
  adapter_checked_allowed: extractedCheck.checker_stdout_json?.adapter_checked_allowed
});
addCheck(checks, "production-ready remains false", extractedCheck.checker_stdout_json?.production_ready_allowed === false, {
  production_ready_allowed: extractedCheck.checker_stdout_json?.production_ready_allowed
});
addCheck(checks, "stable remains false", extractedCheck.checker_stdout_json?.stable_allowed === false, {
  stable_allowed: extractedCheck.checker_stdout_json?.stable_allowed
});
addCheck(checks, "release-gated remains false", extractedCheck.checker_stdout_json?.release_gated_allowed === false, {
  release_gated_allowed: extractedCheck.checker_stdout_json?.release_gated_allowed
});

const failures = checks.filter((check) => check.status !== "pass");
const unresolvedItems = failures.map((failure) => ({
  id: failure.name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, ""),
  status: "blocked",
  reason: failure.name,
  detail: failure.detail
}));

const report = {
  status: failures.length === 0 ? "pass" : "fail",
  stage: STAGE,
  generated_at: new Date().toISOString(),
  weak_claim_recorded: "self-contained-clean-export-checked",
  export_path: CLEAN_EXPORT_PATH,
  export_sha256: exportSha256,
  export_entry_count: entries.length,
  required_entries_missing: missingRequiredEntries,
  current_state_json_included: entrySet.has("CURRENT_STATE.json"),
  current_state_yaml_included: entrySet.has("CURRENT_STATE.yaml"),
  start_here_included: entrySet.has("START_HERE_FOR_AGENTS.ko.md"),
  agent_bootstrap_included: entrySet.has("AGENT_BOOTSTRAP.ko.md"),
  self_contained_checker_included: entrySet.has("tools/check_agent_ready_self_contained.mjs"),
  clean_export_self_contained_checker_included: entrySet.has("tools/check_clean_export_self_contained.mjs"),
  self_contained_evidence_included: entries.some((entry) => entry.startsWith("evidence/self-contained-agent-ready-check/")),
  internal_archive_sha_reports_included: bad.internal_archive_sha_reports.length > 0,
  extracted_self_contained_agent_check_passed: extractedCheck.status === "pass",
  extracted_self_contained_agent_check: extractedCheck,
  node_modules_included: bad.node_modules.length > 0,
  dist_included: bad.dist.length > 0,
  git_metadata_included: bad.git_metadata.length > 0,
  ds_store_included: bad.ds_store.length > 0,
  old_exports_included: bad.old_exports.length > 0,
  archive_legacy_handoffs_included: bad.archive_legacy_handoffs.length > 0,
  nested_prompt_stack_v2_included: bad.nested_prompt_stack_v2.length > 0,
  raw_payload_included: bad.raw_payload_path.length > 0,
  secret_values_included: bad.secret_value_path.length > 0 || leaks.length > 0,
  stale_sha_present: staleShaMatches.length > 0,
  self_referential_sha_hard_code_present: selfShaMatches.length > 0,
  stale_sha_matches: staleShaMatches,
  self_referential_sha_matches: selfShaMatches,
  provider_verified_allowed: false,
  adapter_checked_allowed: false,
  production_ready_allowed: false,
  stable_allowed: false,
  release_gated_allowed: false,
  checks,
  failures,
  unresolved_items_count: unresolvedItems.length,
  unresolved_items: unresolvedItems
};

const gateReport = {
  status: report.status,
  stage: STAGE,
  generated_at: report.generated_at,
  self_contained_agent_ready_check_recorded: extractedCheck.checker_stdout_json?.status === "pass",
  self_contained_clean_export_checked: report.status === "pass",
  current_state_json_recorded: report.current_state_json_included,
  dependency_free: extractedCheck.checker_stdout_json?.dependency_free === true,
  clean_export_path: CLEAN_EXPORT_PATH,
  clean_export_sha256: exportSha256,
  clean_export_entry_count: entries.length,
  stale_sha_present: staleShaMatches.length > 0,
  self_referential_sha_hard_code_present: selfShaMatches.length > 0,
  provider_verified_allowed: false,
  adapter_checked_allowed: false,
  production_ready_allowed: false,
  stable_allowed: false,
  release_gated_allowed: false,
  unresolved_items_count: unresolvedItems.length
};

writeJson(`${EVIDENCE_DIR}/self_contained_clean_export_check.json`, report);
writeJson(`${EVIDENCE_DIR}/self_contained_gate_report.json`, gateReport);
writeJson(`${EVIDENCE_DIR}/unresolved_items.json`, {
  status: report.status === "pass" ? "pass" : "blocked",
  stage: STAGE,
  generated_at: report.generated_at,
  unresolved_items_count: unresolvedItems.length,
  unresolved_items: unresolvedItems
});

console.log(JSON.stringify(report, null, 2));
process.exit(report.status === "pass" ? 0 : 1);
