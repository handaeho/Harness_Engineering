#!/usr/bin/env node
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";

const STAGE = "v2.0.0-post-clean-export-internal-sha-report-scrub";
const EVIDENCE_DIR = "evidence/clean-artifact-prune";
const CLEAN_EXPORT_PATH = "exports/prompt-stack-v2-final-agent-ready.zip";

const CLEAN_EXPORT_ROOTS = [
  "CURRENT_STATE.json",
  "CURRENT_STATE.yaml",
  "START_HERE_FOR_AGENTS.ko.md",
  "AGENT_BOOTSTRAP.ko.md",
  "AGENTS.md",
  "README.md",
  "FINAL_HANDOFF.ko.md",
  "FINAL_NEW_CONVERSATION_PROMPT.ko.md",
  "MANIFEST.asset_classes.yaml",
  "stack.yaml",
  "stack.schema.json",
  "package.json",
  "package-lock.json",
  ".gitignore",
  "adapters",
  "core",
  "docs",
  "observability",
  "profiles",
  "release",
  "runtime",
  "schemas",
  "security",
  "tools",
  "evidence/current-state",
  "evidence/post-active-scoped-final-release-dossier",
  "evidence/final-export-refresh-after-final-dossier",
  "evidence/post-active-scoped-final-new-conversation-handoff",
  "evidence/v36-baseline"
];

const REQUIRED_ENTRIES = [
  "CURRENT_STATE.json",
  "CURRENT_STATE.yaml",
  "START_HERE_FOR_AGENTS.ko.md",
  "AGENT_BOOTSTRAP.ko.md",
  "AGENTS.md",
  "README.md",
  "FINAL_HANDOFF.ko.md",
  "FINAL_NEW_CONVERSATION_PROMPT.ko.md",
  "MANIFEST.asset_classes.yaml",
  "stack.yaml",
  "stack.schema.json",
  "package.json",
  "package-lock.json",
  "docs/how_to_apply_harness_to_agents.ko.md",
  "docs/agent_ready_self_contained_mode.ko.md",
  "profiles/agents/codex_goal_executor.yaml",
  "profiles/agents/chatgpt_reviewer.yaml",
  "profiles/agents/local_runtime_operator.yaml",
  "profiles/agents/release_gate_reviewer.yaml",
  "tools/check_current_state_alignment.mjs",
  "tools/scan_prohibited_claims.mjs",
  "tools/compare_v36_baseline.mjs",
  "tools/check_agent_ready_self_contained.mjs",
  "tools/check_clean_export_self_contained.mjs",
  "tools/validate_alpha.mjs",
  "release/claim_ladder.md",
  "release/release_gate.yaml",
  "release/self_contained_agent_ready_check_scope.yaml",
  "release/self_contained_agent_ready_claim_boundary.yaml",
  "evidence/current-state/current_state_index.json",
  "evidence/post-active-scoped-final-release-dossier/final_release_dossier.json",
  "evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json",
  "evidence/post-active-scoped-final-new-conversation-handoff/final_new_conversation_handoff_report.json",
  "evidence/v36-baseline/checksums.json"
];

const INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES = [
  "evidence/self-contained-agent-ready-check/self_contained_clean_export_check.json",
  "evidence/self-contained-agent-ready-check/self_contained_gate_report.json"
];

const repoRoot = process.cwd();
const root = path.basename(repoRoot) === "prompt-stack-v2"
  ? repoRoot
  : path.resolve(repoRoot, "prompt-stack-v2");

function p(...parts) {
  return path.join(root, ...parts);
}

function rel(absPath) {
  return path.relative(root, absPath).split(path.sep).join("/");
}

function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
}

function sha256File(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function shouldSkip(absPath) {
  const relPath = rel(absPath);
  if (!relPath || relPath === ".") return false;
  if (relPath === "node_modules" || relPath.startsWith("node_modules/") || relPath.includes("/node_modules/")) return true;
  if (relPath === "dist" || relPath.startsWith("dist/") || relPath.includes("/dist/")) return true;
  if (relPath === ".git" || relPath.startsWith(".git/") || relPath.includes("/.git/")) return true;
  if (relPath === "prompt-stack-v2" || relPath.startsWith("prompt-stack-v2/") || relPath.includes("/prompt-stack-v2/")) return true;
  if (relPath === "exports" || relPath.startsWith("exports/")) return true;
  if (relPath === "archive/legacy-handoffs" || relPath.startsWith("archive/legacy-handoffs/")) return true;
  if (path.basename(absPath) === ".DS_Store") return true;
  return false;
}

function copyIntoStage(relPath, stageRoot) {
  const source = p(relPath);
  if (!fs.existsSync(source)) return;
  const destination = path.join(stageRoot, ...relPath.split("/"));
  if (fs.statSync(source).isDirectory()) {
    fs.cpSync(source, destination, {
      recursive: true,
      filter: (item) => !shouldSkip(item)
    });
    return;
  }
  if (shouldSkip(source)) return;
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  fs.copyFileSync(source, destination);
}

function zipEntries(zipPath) {
  const result = spawnSync("zipinfo", ["-1", zipPath], {
    encoding: "utf8",
    maxBuffer: 80 * 1024 * 1024
  });
  return result.status === 0 ? result.stdout.split(/\r?\n/).filter(Boolean).sort() : [];
}

function forbiddenEntries(entries) {
  return {
    node_modules: entries.filter((entry) => entry === "node_modules/" || entry.startsWith("node_modules/") || entry.includes("/node_modules/")),
    dist: entries.filter((entry) => entry === "dist/" || entry.startsWith("dist/") || entry.includes("/dist/")),
    git_metadata: entries.filter((entry) => entry === ".git/" || entry.startsWith(".git/") || entry.includes("/.git/")),
    ds_store: entries.filter((entry) => path.basename(entry) === ".DS_Store"),
    old_exports: entries.filter((entry) => entry.startsWith("exports/") && entry.endsWith(".zip")),
    archive_legacy_handoffs: entries.filter((entry) => entry === "archive/legacy-handoffs/" || entry.startsWith("archive/legacy-handoffs/")),
    nested_prompt_stack_v2: entries.filter((entry) => entry === "prompt-stack-v2/" || entry.startsWith("prompt-stack-v2/") || entry.includes("/prompt-stack-v2/")),
    internal_archive_sha_reports: entries.filter((entry) => INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES.includes(entry)),
    raw_payload_path: entries.filter((entry) => /(^|\/)(raw[-_])?(request|response)[-_]?payload/i.test(entry)
      || /(^|\/)raw[-_](request|response)/i.test(entry)),
    secret_value_path: entries.filter((entry) => /(^|\/)(secret|api[-_]?key|auth[-_]?header)[-_]?value/i.test(entry)
      || /(^|\/)\.env($|\.)/i.test(entry))
  };
}

function fileRecord(relPath) {
  const file = p(relPath);
  return {
    path: relPath,
    exists: fs.existsSync(file),
    sha256: fs.existsSync(file) && fs.statSync(file).isFile() ? sha256File(file) : null
  };
}

const pruneReport = JSON.parse(fs.readFileSync(p(`${EVIDENCE_DIR}/clean_artifact_prune_report.json`), "utf8"));
if (pruneReport.status !== "pass") {
  console.error("Refusing clean export: clean artifact prune did not pass.");
  process.exit(1);
}

const stageRoot = path.join(os.tmpdir(), `prompt-stack-v2-final-agent-ready-${process.pid}`);
fs.rmSync(stageRoot, { recursive: true, force: true });
fs.mkdirSync(stageRoot, { recursive: true });
for (const relPath of CLEAN_EXPORT_ROOTS) copyIntoStage(relPath, stageRoot);

const exportAbs = p(CLEAN_EXPORT_PATH);
fs.mkdirSync(path.dirname(exportAbs), { recursive: true });
fs.rmSync(exportAbs, { force: true });
const zip = spawnSync("zip", ["-qr", exportAbs, "."], {
  cwd: stageRoot,
  encoding: "utf8",
  maxBuffer: 80 * 1024 * 1024
});
fs.rmSync(stageRoot, { recursive: true, force: true });

const created = zip.status === 0 && fs.existsSync(exportAbs);
const entries = created ? zipEntries(exportAbs) : [];
const entrySet = new Set(entries);
const missingRequiredEntries = REQUIRED_ENTRIES.filter((entry) => !entrySet.has(entry));
const bad = forbiddenEntries(entries);
const forbiddenCount = Object.values(bad).reduce((sum, items) => sum + items.length, 0);
const sha256 = created ? sha256File(exportAbs) : null;

const report = {
  status: created && missingRequiredEntries.length === 0 && forbiddenCount === 0 ? "pass" : "fail",
  stage: STAGE,
  generated_at: new Date().toISOString(),
  weak_claim_recorded: "agent-ready-clean-export-created",
  export_path: CLEAN_EXPORT_PATH,
  export_sha256: sha256,
  export_entry_count: entries.length,
  current_state_json_included: entrySet.has("CURRENT_STATE.json"),
  current_state_layer_included: entrySet.has("CURRENT_STATE.yaml") && entrySet.has("evidence/current-state/current_state_index.json"),
  start_here_included: entrySet.has("START_HERE_FOR_AGENTS.ko.md"),
  agent_bootstrap_included: entrySet.has("AGENT_BOOTSTRAP.ko.md"),
  agent_profiles_included: [
    "profiles/agents/codex_goal_executor.yaml",
    "profiles/agents/chatgpt_reviewer.yaml",
    "profiles/agents/local_runtime_operator.yaml",
    "profiles/agents/release_gate_reviewer.yaml"
  ].every((entry) => entrySet.has(entry)),
  final_dossier_evidence_included: entrySet.has("evidence/post-active-scoped-final-release-dossier/final_release_dossier.json")
    && entrySet.has("evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json"),
  self_contained_checker_included: entrySet.has("tools/check_agent_ready_self_contained.mjs")
    && entrySet.has("tools/check_clean_export_self_contained.mjs"),
  self_contained_evidence_included: entries.some((entry) => entry.startsWith("evidence/self-contained-agent-ready-check/")),
  internal_archive_sha_reports_included: bad.internal_archive_sha_reports.length > 0,
  node_modules_included: bad.node_modules.length > 0,
  dist_included: bad.dist.length > 0,
  git_metadata_included: bad.git_metadata.length > 0,
  ds_store_included: bad.ds_store.length > 0,
  old_exports_included: bad.old_exports.length > 0,
  nested_prompt_stack_v2_included: bad.nested_prompt_stack_v2.length > 0,
  archive_legacy_handoffs_included: bad.archive_legacy_handoffs.length > 0,
  raw_payload_included: bad.raw_payload_path.length > 0,
  secret_values_included: bad.secret_value_path.length > 0,
  provider_verified_allowed: false,
  adapter_checked_allowed: false,
  production_ready_allowed: false,
  stable_allowed: false,
  release_gated_allowed: false,
  missing_required_entries: missingRequiredEntries,
  forbidden_entries: bad,
  zip_exit_code: zip.status,
  zip_stderr: zip.stderr.trim()
};

const manifest = {
  status: report.status === "pass" ? "exported" : "fail",
  stage: STAGE,
  generated_at: report.generated_at,
  export_path: CLEAN_EXPORT_PATH,
  export_sha256: sha256,
  export_entry_count: entries.length,
  included_roots: CLEAN_EXPORT_ROOTS,
  required_entries: REQUIRED_ENTRIES,
  package_entries: entries,
  excluded_roots: ["node_modules", "dist", ".git", "exports", "archive/legacy-handoffs", "prompt-stack-v2", "evidence/self-contained-agent-ready-check"],
  excluded_internal_archive_sha_report_entries: INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES
};

writeJson(p(`${EVIDENCE_DIR}/agent_ready_clean_export_report.json`), report);
writeJson(p(`${EVIDENCE_DIR}/agent_ready_clean_export_manifest.json`), manifest);
writeJson(p(`${EVIDENCE_DIR}/agent_ready_clean_export_checksums.json`), {
  status: "recorded",
  stage: STAGE,
  export: {
    path: CLEAN_EXPORT_PATH,
    sha256
  },
  required_entry_source_checksums: REQUIRED_ENTRIES.map(fileRecord)
});

console.log(JSON.stringify(report, null, 2));
process.exit(report.status === "pass" ? 0 : 1);
