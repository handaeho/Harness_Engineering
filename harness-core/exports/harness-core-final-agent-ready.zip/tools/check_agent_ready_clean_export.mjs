#!/usr/bin/env node
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { parse as parseYaml } from "yaml";

const STAGE = "v2.0.0-post-clean-export-internal-sha-report-scrub";
const EVIDENCE_DIR = "evidence/clean-artifact-prune";
const CLEAN_EXPORT_PATH = "exports/prompt-stack-v2-final-agent-ready.zip";
const OLD_CLEAN_EXPORT_SHA_VALUES = [
  [
    "88748e3f",
    "3a61f06d",
    "4b7c170d",
    "798db524",
    "95c5aa1e",
    "4f93e329",
    "5960eb59",
    "b0336f35"
  ].join(""),
  [
    "ffd62ac5",
    "9971f262",
    "7d7ecd9f",
    "04c18747",
    "903ffdba",
    "606bc5a9",
    "a8a1744b",
    "84c4554a"
  ].join("")
];

const INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES = [
  "evidence/self-contained-agent-ready-check/self_contained_clean_export_check.json",
  "evidence/self-contained-agent-ready-check/self_contained_gate_report.json"
];

const REQUIRED_ENTRIES = [
  "CURRENT_STATE.json",
  "CURRENT_STATE.yaml",
  "START_HERE_FOR_AGENTS.ko.md",
  "AGENT_BOOTSTRAP.ko.md",
  "AGENTS.md",
  "README.md",
  "FINAL_HANDOFF.ko.md",
  "FINAL_NEW_CONVERSATION_PROMPT.ko.md",
  "MANIFEST.asset_classes.yaml",
  "stack.yaml",
  "stack.schema.json",
  "package.json",
  "package-lock.json",
  "docs/how_to_apply_harness_to_agents.ko.md",
  "docs/agent_ready_self_contained_mode.ko.md",
  "profiles/agents/codex_goal_executor.yaml",
  "profiles/agents/chatgpt_reviewer.yaml",
  "profiles/agents/local_runtime_operator.yaml",
  "profiles/agents/release_gate_reviewer.yaml",
  "tools/check_current_state_alignment.mjs",
  "tools/scan_prohibited_claims.mjs",
  "tools/compare_v36_baseline.mjs",
  "tools/check_agent_ready_self_contained.mjs",
  "tools/check_clean_export_self_contained.mjs",
  "tools/validate_alpha.mjs",
  "release/claim_ladder.md",
  "release/release_gate.yaml",
  "release/self_contained_agent_ready_check_scope.yaml",
  "release/self_contained_agent_ready_claim_boundary.yaml",
  "evidence/current-state/current_state_index.json",
  "evidence/current-state/current_state_gate_report.json",
  "evidence/current-state/current_state_claim_boundary.json",
  "evidence/post-active-scoped-final-release-dossier/final_release_dossier.json",
  "evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json",
  "evidence/post-active-scoped-final-new-conversation-handoff/final_new_conversation_handoff_report.json",
  "evidence/v36-baseline/checksums.json"
];

const BLOCKED_CLAIMS = [
  "provider-verified",
  "adapter-checked",
  "production-ready",
  "stable",
  "release-gated"
];

const repoRoot = process.cwd();
const root = path.basename(repoRoot) === "prompt-stack-v2"
  ? repoRoot
  : path.resolve(repoRoot, "prompt-stack-v2");

function p(...parts) {
  return path.join(root, ...parts);
}

function writeJson(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify(data, null, 2)}\n`);
}

function sha256File(file) {
  return crypto.createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function addCheck(checks, name, pass, detail = {}) {
  checks.push({ name, status: pass ? "pass" : "fail", detail });
}

function zipEntries(zipPath) {
  const result = spawnSync("zipinfo", ["-1", zipPath], {
    encoding: "utf8",
    maxBuffer: 80 * 1024 * 1024
  });
  return {
    exit_code: result.status,
    stderr: result.stderr.trim(),
    entries: result.status === 0 ? result.stdout.split(/\r?\n/).filter(Boolean).sort() : []
  };
}

function unzipText(zipPath, entry) {
  const result = spawnSync("unzip", ["-p", zipPath, entry], {
    encoding: "utf8",
    maxBuffer: 40 * 1024 * 1024
  });
  return result.status === 0 ? result.stdout : "";
}

function readZipJson(zipPath, entry) {
  try {
    return JSON.parse(unzipText(zipPath, entry));
  } catch {
    return null;
  }
}

function forbiddenEntries(entries) {
  return {
    node_modules: entries.filter((entry) => entry === "node_modules/" || entry.startsWith("node_modules/") || entry.includes("/node_modules/")),
    dist: entries.filter((entry) => entry === "dist/" || entry.startsWith("dist/") || entry.includes("/dist/")),
    git_metadata: entries.filter((entry) => entry === ".git/" || entry.startsWith(".git/") || entry.includes("/.git/")),
    ds_store: entries.filter((entry) => path.basename(entry) === ".DS_Store"),
    old_exports: entries.filter((entry) => entry.startsWith("exports/") && entry.endsWith(".zip")),
    archive_legacy_handoffs: entries.filter((entry) => entry === "archive/legacy-handoffs/" || entry.startsWith("archive/legacy-handoffs/")),
    nested_prompt_stack_v2: entries.filter((entry) => entry === "prompt-stack-v2/" || entry.startsWith("prompt-stack-v2/") || entry.includes("/prompt-stack-v2/")),
    internal_archive_sha_reports: entries.filter((entry) => INTERNAL_ARCHIVE_SHA_REPORT_ENTRIES.includes(entry)),
    raw_payload_path: entries.filter((entry) => /(^|\/)(raw[-_])?(request|response)[-_]?payload/i.test(entry)
      || /(^|\/)raw[-_](request|response)/i.test(entry)),
    secret_value_path: entries.filter((entry) => /(^|\/)(secret|api[-_]?key|auth[-_]?header)[-_]?value/i.test(entry)
      || /(^|\/)\.env($|\.)/i.test(entry))
  };
}

function isPolicyOrPatternEntry(entry) {
  return /(^|\/)(secret_detection_patterns|raw_storage_forbidden_patterns|telemetry_sink_credential_policy|credential_policy|redaction_policy|provider_canary_attempts)/i.test(entry);
}

function secretContentLeaks(zipPath, entries) {
  const leaks = [];
  const patterns = [
    { id: "openai_api_key_like_value", pattern: /\bsk-[A-Za-z0-9_-]{20,}\b/g },
    { id: "authorization_bearer_value", pattern: /authorization\s*:\s*bearer\s+(?!<|YOUR_|REDACTED|redacted|placeholder|example)[A-Za-z0-9._~+/=-]{12,}/gi },
    { id: "api_key_assigned_value", pattern: /\b(api[-_]?key|auth[-_]?header|secret)\b\s*[:=]\s*["']?(?!false\b|true\b|null\b|none\b|missing\b|redacted\b|REDACTED\b|placeholder\b|example\b|not_applicable\b|needs_verification\b|forbidden\b|blocked\b)[A-Za-z0-9._~+/=-]{24,}/gi }
  ];
  for (const entry of entries) {
    if (!/\.(md|txt|yaml|yml|json|mjs|js|schema|lock)$/i.test(entry)) continue;
    if (isPolicyOrPatternEntry(entry)) continue;
    const text = unzipText(zipPath, entry);
    for (const item of patterns) {
      item.pattern.lastIndex = 0;
      const match = item.pattern.exec(text);
      if (match) {
        leaks.push({ entry, pattern: item.id, excerpt: match[0].slice(0, 24) });
        break;
      }
    }
  }
  return leaks;
}

function textEntries(entries) {
  return entries.filter((entry) => /\.(md|txt|yaml|yml|json|mjs|js|schema|lock)$/i.test(entry));
}

function findTextOccurrences(zipPath, entries, values) {
  const matches = [];
  const needles = values.filter(Boolean);
  for (const entry of textEntries(entries)) {
    const text = unzipText(zipPath, entry);
    for (const value of needles) {
      if (text.includes(value)) {
        matches.push({ entry, value });
      }
    }
  }
  return matches;
}

const exportAbs = p(CLEAN_EXPORT_PATH);
const checks = [];
const exists = fs.existsSync(exportAbs);
const exportSha256 = exists ? sha256File(exportAbs) : null;
addCheck(checks, "clean export exists", exists, { export_path: CLEAN_EXPORT_PATH });
const zip = exists ? zipEntries(exportAbs) : { exit_code: 1, stderr: "missing export", entries: [] };
const entries = zip.entries;
const entrySet = new Set(entries);
addCheck(checks, "zip entries readable", zip.exit_code === 0, { exit_code: zip.exit_code, stderr: zip.stderr });
for (const entry of REQUIRED_ENTRIES) {
  addCheck(checks, `${entry} included`, entrySet.has(entry), { entry });
}

const currentStateText = exists ? unzipText(exportAbs, "CURRENT_STATE.yaml") : "";
let currentState = null;
try {
  currentState = currentStateText ? parseYaml(currentStateText) : null;
} catch {
  currentState = null;
}
const claimBoundary = exists ? readZipJson(exportAbs, "evidence/current-state/current_state_claim_boundary.json") : null;
const gate = exists ? readZipJson(exportAbs, "evidence/current-state/current_state_gate_report.json") : null;
const bad = forbiddenEntries(entries);
const leaks = exists ? secretContentLeaks(exportAbs, entries) : [];
const staleShaMatches = exists ? findTextOccurrences(exportAbs, entries, OLD_CLEAN_EXPORT_SHA_VALUES) : [];
const selfShaMatches = exists ? findTextOccurrences(exportAbs, entries, [exportSha256]) : [];

addCheck(checks, "current state layer included", entrySet.has("CURRENT_STATE.yaml")
  && entrySet.has("evidence/current-state/current_state_index.json")
  && entrySet.has("evidence/current-state/current_state_gate_report.json"));
addCheck(checks, "CURRENT_STATE.json included", entrySet.has("CURRENT_STATE.json"));
addCheck(checks, "START_HERE_FOR_AGENTS.ko.md included", entrySet.has("START_HERE_FOR_AGENTS.ko.md"));
addCheck(checks, "agent bootstrap included", entrySet.has("AGENT_BOOTSTRAP.ko.md"));
addCheck(checks, "agent profiles included", [
  "profiles/agents/codex_goal_executor.yaml",
  "profiles/agents/chatgpt_reviewer.yaml",
  "profiles/agents/local_runtime_operator.yaml",
  "profiles/agents/release_gate_reviewer.yaml"
].every((entry) => entrySet.has(entry)));
addCheck(checks, "final dossier evidence included", entrySet.has("evidence/post-active-scoped-final-release-dossier/final_release_dossier.json")
  && entrySet.has("evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json"));
addCheck(checks, "self-contained checker included", entrySet.has("tools/check_agent_ready_self_contained.mjs")
  && entrySet.has("tools/check_clean_export_self_contained.mjs"));
addCheck(checks, "internal archive SHA self-contained reports not included", bad.internal_archive_sha_reports.length === 0, {
  entries: bad.internal_archive_sha_reports
});
addCheck(checks, "node_modules not included", bad.node_modules.length === 0, { entries: bad.node_modules });
addCheck(checks, "dist not included", bad.dist.length === 0, { entries: bad.dist });
addCheck(checks, ".git not included", bad.git_metadata.length === 0, { entries: bad.git_metadata });
addCheck(checks, ".DS_Store not included", bad.ds_store.length === 0, { entries: bad.ds_store });
addCheck(checks, "old exports not included", bad.old_exports.length === 0, { entries: bad.old_exports });
addCheck(checks, "archive/legacy-handoffs not included", bad.archive_legacy_handoffs.length === 0, { entries: bad.archive_legacy_handoffs });
addCheck(checks, "nested prompt-stack-v2 residue not included", bad.nested_prompt_stack_v2.length === 0, { entries: bad.nested_prompt_stack_v2 });
addCheck(checks, "raw/secret path entries not included", bad.raw_payload_path.length === 0 && bad.secret_value_path.length === 0, { entries: bad });
addCheck(checks, "raw/secret values not included", leaks.length === 0, { leaks });
addCheck(checks, "stale clean export SHA not present", staleShaMatches.length === 0, { matches: staleShaMatches });
addCheck(checks, "clean export does not hard-code its own SHA", selfShaMatches.length === 0, { matches: selfShaMatches });
addCheck(checks, "agent_ready_export separated from latest_dossier_export", currentState?.latest_export === undefined
  && currentState?.agent_ready_export?.path === "exports/prompt-stack-v2-final-agent-ready.zip"
  && currentState?.latest_dossier_export?.path === "exports/v2.0.0-rc.1-postrc-final-dossier-export.zip", {
  latest_export: currentState?.latest_export || null,
  agent_ready_export: currentState?.agent_ready_export || null,
  latest_dossier_export: currentState?.latest_dossier_export || null
});
addCheck(checks, "agent_ready_export checksum is external", currentState?.agent_ready_export?.checksum_report_path === "evidence/clean-artifact-prune/agent_ready_clean_export_report.json"
  && currentState?.agent_ready_export?.sha256 === undefined, {
  agent_ready_export: currentState?.agent_ready_export || null
});
for (const claim of BLOCKED_CLAIMS) {
  addCheck(checks, `${claim} remains blocked`, currentStateText.includes(`- ${claim}`)
    && claimBoundary?.blocked_claims?.includes(claim), {
    current_state_contains_claim: currentStateText.includes(`- ${claim}`),
    claim_boundary_contains_claim: claimBoundary?.blocked_claims?.includes(claim)
  });
}
addCheck(checks, "provider-verified remains false", claimBoundary?.provider_verified_allowed === false && gate?.provider_verified_allowed === false);
addCheck(checks, "adapter-checked remains false", claimBoundary?.adapter_checked_allowed === false && gate?.adapter_checked_allowed === false);
addCheck(checks, "production-ready remains false", claimBoundary?.production_ready_allowed === false && gate?.production_ready_allowed === false);
addCheck(checks, "stable remains false", claimBoundary?.stable_allowed === false && gate?.stable_allowed === false);
addCheck(checks, "release-gated remains false", claimBoundary?.release_gated_allowed === false && gate?.release_gated_allowed === false);

const failures = checks.filter((check) => check.status !== "pass");
const report = {
  status: failures.length === 0 ? "pass" : "fail",
  stage: STAGE,
  generated_at: new Date().toISOString(),
  weak_claim_recorded: "clean-artifact-gate-checked",
  export_path: CLEAN_EXPORT_PATH,
  export_sha256: exportSha256,
  export_entry_count: entries.length,
  current_state_json_included: entrySet.has("CURRENT_STATE.json"),
  current_state_layer_included: entrySet.has("CURRENT_STATE.yaml") && entrySet.has("evidence/current-state/current_state_index.json"),
  start_here_included: entrySet.has("START_HERE_FOR_AGENTS.ko.md"),
  agent_bootstrap_included: entrySet.has("AGENT_BOOTSTRAP.ko.md"),
  agent_profiles_included: [
    "profiles/agents/codex_goal_executor.yaml",
    "profiles/agents/chatgpt_reviewer.yaml",
    "profiles/agents/local_runtime_operator.yaml",
    "profiles/agents/release_gate_reviewer.yaml"
  ].every((entry) => entrySet.has(entry)),
  final_dossier_evidence_included: entrySet.has("evidence/post-active-scoped-final-release-dossier/final_release_dossier.json")
    && entrySet.has("evidence/final-export-refresh-after-final-dossier/final_export_refresh_after_final_dossier_report.json"),
  self_contained_checker_included: entrySet.has("tools/check_agent_ready_self_contained.mjs")
    && entrySet.has("tools/check_clean_export_self_contained.mjs"),
  self_contained_evidence_included: entries.some((entry) => entry.startsWith("evidence/self-contained-agent-ready-check/")),
  internal_archive_sha_reports_included: bad.internal_archive_sha_reports.length > 0,
  node_modules_included: bad.node_modules.length > 0,
  dist_included: bad.dist.length > 0,
  git_metadata_included: bad.git_metadata.length > 0,
  ds_store_included: bad.ds_store.length > 0,
  old_exports_included: bad.old_exports.length > 0,
  archive_legacy_handoffs_included: bad.archive_legacy_handoffs.length > 0,
  nested_prompt_stack_v2_included: bad.nested_prompt_stack_v2.length > 0,
  raw_payload_included: bad.raw_payload_path.length > 0,
  secret_values_included: bad.secret_value_path.length > 0 || leaks.length > 0,
  stale_sha_present: staleShaMatches.length > 0,
  self_referential_sha_hard_code_present: selfShaMatches.length > 0,
  stale_sha_matches: staleShaMatches,
  self_referential_sha_matches: selfShaMatches,
  provider_verified_allowed: false,
  adapter_checked_allowed: false,
  production_ready_allowed: false,
  stable_allowed: false,
  release_gated_allowed: false,
  checks,
  failures,
  unresolved_items_count: failures.length,
  unresolved_items: failures.map((failure) => ({
    id: failure.name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, ""),
    status: "blocked",
    reason: failure.name,
    detail: failure.detail
  }))
};

writeJson(p(`${EVIDENCE_DIR}/agent_ready_clean_export_report.json`), report);
writeJson(p(`${EVIDENCE_DIR}/unresolved_items.json`), {
  status: report.status === "pass" ? "pass" : "blocked",
  stage: STAGE,
  unresolved_items_count: report.unresolved_items_count,
  unresolved_items: report.unresolved_items
});

console.log(JSON.stringify(report, null, 2));
process.exit(report.status === "pass" ? 0 : 1);
