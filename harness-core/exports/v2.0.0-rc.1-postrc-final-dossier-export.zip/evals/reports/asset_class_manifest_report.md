# Asset Class Manifest Report

Status: pass

Stage: v2.0.0-rc.1-agents-md-and-system-of-record-alignment

## Classes

- core_source
- evidence
- human_docs
- generated_or_ignored
- immutable_baseline
